import KnowledgeBasePrototype from "../components/KnowledgeBasePrototype";

export default function Home() {
  return <KnowledgeBasePrototype />;
}
